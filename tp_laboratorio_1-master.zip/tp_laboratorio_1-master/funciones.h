#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED

float sumar(float num1, float num2);
float restar(float num1, float num2);
float dividir(float num1, float num2);
float multiplicar(float num1, float num2);
double factorial(float num1);

#endif // FUNCIONES_H_INCLUDED
