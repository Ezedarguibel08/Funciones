# Bibliotecas-para-Parcial
Biblioteca de funciones para el primer parcial
