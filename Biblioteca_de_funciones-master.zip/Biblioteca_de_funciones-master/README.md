# Biblioteca de funciones C

Este repositorio contiene todas las funciones usadas durante el primer cuatrimestre.

## Lenguajes

Los lenguajes tratados fueron:

* C

## Tecnologias utilizadas

<table>
    <tbody>
        <tr>
            <td><img src="./Z. img/codeblocks.jpg" width="20px" height="20px"/></td>
            <td><a href="http://www.codeblocks.org/">Code::Blocks</a></td>
        <tr>
    </tbody>
</table>

## Profesores

* David Fernandez
* German Scarafilo

## Autor

* Fernando Lareu - [1caruxx](https://github.com/1caruxx)

# License

This project is licensed under the GNU General Public License v3.0 - see the [LICENSE](https://github.com/1caruxx/Biblioteca_de_funciones/blob/master/LICENSE) file for details.
