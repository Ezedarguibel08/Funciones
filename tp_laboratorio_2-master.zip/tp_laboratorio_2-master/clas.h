typedef struct{

 int id;
 char name[20];

} eSector;

typedef struct{

 int id;
 char name[51];
 char lastName[51];
 float salary;
 int sector;
 int isEmpty;

} eEmployee;

int funcionMenu ();
int hayEmpleados(eEmployee nomina[], int tam);
int inicializarEmpleados (eEmployee nomina[], int tam);
int agregarEmpleado(eEmployee nomina[], eSector sectores[], int tam, int tamSec);
int buscarLibre(eEmployee nomina[], int tam);
void conseguirNombre(eEmployee nomina[], int index, char mensaje[], char mensajeError[]);
void conseguirApellido(eEmployee nomina[], int index, char mensaje[], char mensajeError[]);
int generarId(eEmployee nomina[], int tam);
float conseguirSalario(char mensaje[], char mensajeError[]);
int elegirSector(eSector sectores[], int tamSec);
void mostrarSectores(eSector sectores[], int tamSec);
void inicializarSectores(eSector sectores[], int tamSec);
void hardCodearSectores(eSector sectores[], int tamSec);
void modificarEmpleado(eEmployee nomina[], eSector sectores[], int tam, int tamSec);
int buscarEmpleado(eEmployee nomina[], int tam, int idABuscar);
void mostrarEmpleado(eEmployee empleado, eSector sectores[], int tamSec);
void mostrarEmpleados(eEmployee nomina[], eSector sectores[], int tam, int tamSec);
int averiguarSector(eEmployee empleado, eSector sectores[], int tamSec);
void bajaEmpleado(eEmployee nomina[], eSector sectores[], int tam, int tamSec);
void cargarSectores(eSector sectores[], int tamSec);
void totalPromedioSalarios(eEmployee nomina[], int tam);
void menuInformes(eEmployee nomina[], eSector sectores[], int tam, int tamSec);
void hardCodearEmpleados(eEmployee nomina[], int tam);
int conseguirPositivo(char mensaje[], char mensajeError[]);
void ordenarEmpleados(eEmployee nomina[], eSector sectores[], int tam, int tamSec);
