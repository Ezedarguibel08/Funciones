#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>
#include "clas.h"

#define TAM 1000
#define TAMSEC 10

int funcionMenu(){

    int rta;

    printf("\n\t----Menu de opciones----");
    printf("\n\n\t0- Cargar sectores");
    printf("\n\t1- Altas");
    printf("\n\t2- Modificar");
    printf("\n\t3- Baja");
    printf("\n\t4- Informar:");
    printf("\n\n\t   1- Listado de empleados ordenados alfabeticamente\n\t   por nombre y sector.");
    printf("\n\t   2- Total y promedio de los salarios,\n\t   y cuantos empleados superan el promedio.");
    printf("\n\n\t5- Salir");
    printf("\n\nOpcion: ");

    scanf("%d", &rta);

    return rta;
}

int inicializarEmpleados (eEmployee nomina[], int tam){

    int funciona=-1;

    for(int i=0 ; i<tam ; i++){
        nomina[i].isEmpty=1;
    }

    if(nomina[tam-1].isEmpty==1){
        funciona=0;
    }

    return funciona;

}

int buscarLibre(eEmployee nomina[], int tam){

    int indexLibre=-1;

    for(int i=0 ; i<tam ; i++){
        if(nomina[i].isEmpty==1){
            indexLibre=i;
            break;
        }
    }

    return indexLibre;

}

int generarId(eEmployee nomina[], int tam){

    int indexLibre=buscarLibre(nomina, tam);
    int idAnterior;
    int id=-1;

    if(indexLibre==0){
        id=1000;
    }else{
        idAnterior=nomina[indexLibre-1].id;
        id=idAnterior+1;
    }

    return id;

}

void conseguirNombre(eEmployee nomina[], int index, char mensaje[], char mensajeError[]){

    char aux[50];
    int len;
    int flagOK;

    printf("\n%s", mensaje);
    fflush(stdin);
    gets(aux);

    do{

        len=strlen(aux);
        flagOK=1;
        for(int i=0 ; i<len ; i++){
            if(isalpha(aux[i])==0){
               flagOK=0;
            }
        }

        if(flagOK==0){
            printf("%s", mensajeError);
            fflush(stdin);
            gets(aux);
        }else{
            strcpy(nomina[index].name, aux);
        }

    }while(flagOK==0);

}

void conseguirApellido(eEmployee nomina[], int index, char mensaje[], char mensajeError[]){

    char aux[50];
    int len;
    int flagOK;

    printf("\n%s", mensaje);
    fflush(stdin);
    gets(aux);

    do{

        len=strlen(aux);
        flagOK=1;
        for(int i=0 ; i<len ; i++){
            if(isalpha(aux[i])==0){
               flagOK=0;
            }
        }

        if(flagOK==0){
            printf("%s", mensajeError);
            fflush(stdin);
            gets(aux);
        }else{
            strcpy(nomina[index].lastName, aux);
        }

    }while(flagOK==0);

}

int agregarEmpleado(eEmployee nomina[], eSector sectores[], int tam, int tamSec){

    int indexLibre=buscarLibre(nomina, tam);
    int idEmp;

    if(indexLibre==-1){
        printf("No hay lugar en el sistema para otro empleado.");
    }else{

        system("cls");
        printf("---Agregar empleado---\n");
        idEmp=generarId(nomina, tam);
        nomina[indexLibre].id=idEmp;
        printf("\nID: %d\n", idEmp);

        conseguirNombre(nomina, indexLibre, "Nombre: ", "Error, ingrese nombre valido: ");
        conseguirApellido(nomina, indexLibre, "Apellido: ", "Error, ingrese apellido valido: ");
        nomina[indexLibre].salary=conseguirSalario("Salario: $", "Error, ingrese salario valido: $");
        nomina[indexLibre].sector=elegirSector(sectores, tamSec);
        nomina[indexLibre].isEmpty=0;

        printf("\nCarga de empleado exitosa, presione una tecla para continuar");
        fflush(stdin);
        getch();

    }

    return 1;

}

float conseguirSalario(char mensaje[], char mensajeError[]){

    char aux[50];
    int len;
    int flagOK;
    float salario;

    printf("\n%s", mensaje);
    fflush(stdin);
    gets(aux);

    do{

        flagOK=1;
        len=strlen(aux);

        for(int i=0 ; i<len ; i++){
            if(isdigit(aux[i])!=1 && aux[i]!='.'){
                flagOK=0;
            }
        }

        if(flagOK==0){
            printf("\n%s", mensajeError);
            fflush(stdin);
            gets(aux);
        }else{
            salario=atof(aux);
        }

    }while(flagOK==0);

    return salario;

}

int conseguirPositivo(char mensaje[], char mensajeError[]){

    char aux[50];
    int len;
    int flagOK;
    int positivo;

    printf("\n%s", mensaje);
    fflush(stdin);
    gets(aux);

    do{

        flagOK=1;
        len=strlen(aux);

        for(int i=0 ; i<len ; i++){
            if(isdigit(aux[i])!=1){
                flagOK=0;
            }
        }

        if(flagOK==0){
            printf("\n%s", mensajeError);
            fflush(stdin);
            gets(aux);
        }else{
            positivo=atoi(aux);
        }

    }while(flagOK==0);

    return positivo;

}

int elegirSector(eSector sectores[], int tamSec){

    int idSector;
    int sectoresEnUso=0;

    for(int i=0 ; i<tamSec ; i++){
        if(sectores[i].id!=0){
            sectoresEnUso++;
        }
    }

    printf("\n\t0- No asignar sector\n");
    mostrarSectores(sectores, tamSec);
    idSector=conseguirPositivo("Elija un sector: ", "Sector invalido. Intente de nuevo: ");

    while(idSector<0 || idSector>sectoresEnUso){
       idSector=conseguirPositivo("Sector invalido. Intente de nuevo: ", "Sector invalido. Intente de nuevo: ");
    }

    return idSector;

}

void mostrarSectores(eSector sectores[], int tamSec){

    for(int i=0 ; i<tamSec ; i++){
        if(sectores[i].id!=0){
            printf("\n\t%d- %s", sectores[i].id, sectores[i].name);
            printf("\n");
        }
    }

}

void inicializarSectores(eSector sectores[], int tamSec){

    for(int i=0 ; i<tamSec ; i++){
        sectores[i].id=0;
        strcpy(sectores[i].name, "Sin sector asignado");
    }

}

void hardCodearSectores(eSector sectores[], int tamSec){

    eSector sectAux[]={{1, "RRHH"},{2, "Ventas"},{3, "Compras"},{4, "Gerencia"},{5, "Calidad"}};

    for(int i=0 ; i<tamSec ; i++){
        sectores[i]=sectAux[i];
    }

}

void modificarEmpleado(eEmployee nomina[], eSector sectores[], int tam, int tamSec){

    int idModificar;
    int indexModificar;
    int campoModificar;

    if(hayEmpleados(nomina, tam)){
        printf("\nAun no se han ingresado empleados\n\n");
        system("pause");
    }else{

        mostrarEmpleados(nomina, sectores, tam, tamSec);
        idModificar=conseguirPositivo("\nIngrese el ID del empleado a modificar: ", "ID invalido. Intente nuevamente: ");
        indexModificar=buscarEmpleado(nomina, tam, idModificar);

        while(indexModificar==-1){
            idModificar=conseguirPositivo("ID invalido. Intente nuevamente: ", "ID invalido. Intente nuevamente: ");
            indexModificar=buscarEmpleado(nomina, tam, idModificar);
        }

        do{
            system("cls");
            printf("\nEmpleado seleccionado legajo %d", idModificar);
            printf("\n\n%4s %12s %12s %10s %9s", "ID", "Nombre", "Apellido", "Salario","Sector");
            mostrarEmpleado(nomina[indexModificar], sectores, tamSec);
            printf("\n\nCampos: ");
            printf("\n\n\t1-Nombre\n\t2-Apellido\n\t3-Salario\n\t4-Sector\n\t5- Terminar modificacion");
            campoModificar=conseguirPositivo("\nIngrese campo a modificar: ","Error. Ingrese campo valido: ");

                switch(campoModificar){
                    case 1:
                        conseguirNombre(nomina, indexModificar, "Ingrese nuevo nombre: ", "Ingrese nombre valido: ");
                        break;
                    case 2:
                        conseguirApellido(nomina, indexModificar, "Ingrese nuevo apellido: ", "Ingrese apellido valido: ");
                        break;
                    case 3:
                        nomina[indexModificar].salary=conseguirSalario("Ingrese nuevo salario: $", "Ingrese salario valido: $");
                        break;
                    case 4:
                         nomina[indexModificar].sector=elegirSector(sectores, tamSec);
                        break;
                    case 5:
                        printf("\n\tModificacion terminada\n\n");
                        system("pause");
                        break;
                    default:
                        system("cls");
                        break;
                }

            }while(campoModificar!=5);

        }
}

int buscarEmpleado(eEmployee nomina[], int tam, int idABuscar){

    int indexEmpleado=-1;

    for(int i=0; i<tam ; i++){
        if(nomina[i].id==idABuscar && nomina[i].isEmpty!=1){
            indexEmpleado=i;
            break;
        }
    }

    return indexEmpleado;
}

void mostrarEmpleado(eEmployee empleado, eSector sectores[], int tamSec){

    int indexSector=averiguarSector(empleado, sectores, tamSec);

    printf("\n%d %12s %12s %10.2f %9s", empleado.id, empleado.name, empleado.lastName, empleado.salary, sectores[indexSector].name);


}

int averiguarSector(eEmployee empleado, eSector sectores[], int tamSec){

    int indexSector;

    for(int i=0 ; i<tamSec ; i++){
        if(empleado.sector==sectores[i].id){
            indexSector=i;
            break;
        }
    }

    return indexSector;

}

void mostrarEmpleados(eEmployee nomina[], eSector sectores[], int tam, int tamSec){


    if(hayEmpleados(nomina, tam)){
        printf("Aun no se han ingresado empleados");
    }else{
         printf("\n%4s %12s %12s %10s %9s \n", "ID", "Nombre", "Apellido", "Salario","Sector");
        for(int i=0 ; i<tam ; i++){
            if(nomina[i].isEmpty!=1){
                mostrarEmpleado(nomina[i], sectores, tamSec);
            }
        }
    }
}

int hayEmpleados(eEmployee nomina[], int tam){

    int empEmpty=1;

    for(int i=0 ; i<tam ; i++){
        if(nomina[i].isEmpty!=1){
            empEmpty=0;
            break;
        }
    }

    return empEmpty;
}

void bajaEmpleado(eEmployee nomina[], eSector sectores[], int tam, int tamSec){

    int idBaja;
    int indexBuscar;
    char confirmoBaja;

    if(hayEmpleados(nomina, tam)){
        printf("\nAun no se han ingresado empleados\n\n");
        system("pause");
    }else{

        mostrarEmpleados(nomina, sectores, tam, tamSec);
        idBaja=conseguirPositivo("\nIngrese el ID a dar de baja: ", "Error. Ingrese nuevamente: ");

        indexBuscar=buscarEmpleado(nomina, TAM, idBaja);

        if(indexBuscar==-1){
                printf("\nNo existe ningun empleado con ese ID\n");
                system("pause");
        }else{
            printf("\nEmpleado con ID %d: ", idBaja);
            printf("\n%4s %12s %12s %10s %9s \n", "ID", "Nombre", "Apellido", "Salario","Sector");
            mostrarEmpleado(nomina[indexBuscar], sectores, averiguarSector(nomina[indexBuscar], sectores, tamSec));

            printf("\n\nConfirmar la baja de este empleado? S/N: ");
            fflush(stdin);
            confirmoBaja=tolower(getchar());

            if(confirmoBaja=='n'){
                printf("\nBaja de empleado cancelada\n");
                system("pause");
            }else{
                printf("\nBaja de empleado confirmada\n");
                system("pause");
                nomina[indexBuscar].isEmpty=1;
            }
        }
    }


}

void cargarSectores(eSector sectores[], int tamSec){

    char rta;
    int j;

    do{
        for(j=0 ; j<tamSec ; j++){
            if(sectores[j].id==0){
                sectores[j].id=j+1;
                break;
            }
        }

        printf("\nSector %d, ingrese descripcion: ", j+1);
        fflush(stdin);
        gets(sectores[j].name);
        printf("\nIngresar otro sector? S/N: ");
        fflush(stdin);
        rta=getchar();
        rta=tolower(rta);

    }while(rta=='s');

}

void totalPromedioSalarios(eEmployee nomina[], int tam){

    float salariosTotal=0;
    int cantidadSalarios=0;
    float promedioSalarios;
    int contadorSuperan=0;

    if(hayEmpleados(nomina, tam)){
        printf("\nAun no se han ingresado empleados");
    }else{

        for(int i=0 ; i<tam ; i++){
            if(nomina[i].isEmpty!=1){
                salariosTotal+=nomina[i].salary;
                cantidadSalarios++;
            }
        }

        promedioSalarios=(float)salariosTotal/cantidadSalarios;

        printf("\nTotal de salarios: $%.2f", salariosTotal);
        printf("\nPromedio de salarios: $%.2f", promedioSalarios);

        for(int i=0 ; i<tam ; i++){
            if(nomina[i].isEmpty!=1 && nomina[i].salary>promedioSalarios)
                contadorSuperan++;
        }

        printf("\nEmpleados que superan el promedio: %d\n", contadorSuperan);
        system("pause");
    }
}

void menuInformes(eEmployee nomina[], eSector sectores[], int tam, int tamSec){

    int rta;

    do{
        system("cls");
        printf("Informes: ");
        printf("\n\n\t1- Listado de empleados ordenados alfabeticamente\n\t   por nombre y sector");
        printf("\n\n\t2- Total y promedio de los salarios,\n\t   y cuantos empleados superan el promedio.");
        printf("\n\n\t3-Volver al menu principal");
        printf("\n\nOpcion: ");
        scanf("%d", &rta);

        switch(rta){
            case 1:
                ordenarEmpleados(nomina, sectores, tam, tamSec);
                mostrarEmpleados(nomina, sectores, tam, tamSec);
                system("pause");
                break;
            case 2:
                totalPromedioSalarios(nomina, tam);
                system("pause");
                break;
            case 3:
                break;
            default:
                system("cls");
        }

    }while(rta!=3);

}


void ordenarEmpleados(eEmployee nomina[], eSector sectores[], int tam, int tamSec){

    eEmployee auxEmp;

    for(int i=0 ; i<tam-1 ; i++){
        for(int j=i+1 ; j<tam ; j++){
            if(nomina[i].sector>nomina[j].sector){
                auxEmp=nomina[i];
                nomina[i]=nomina[j];
                nomina[j]=auxEmp;
            }
        }
    }

    for(int i=0 ; i<tam-1 ; i++){
        for(int j=i+1 ; j<tam ; j++){
            if(nomina[i].sector==nomina[j].sector && stricmp(nomina[i].name, nomina[j].name)==1){
                auxEmp=nomina[i];
                nomina[i]=nomina[j];
                nomina[j]=auxEmp;
            }else{
                if(nomina[i].sector==nomina[j].sector && stricmp(nomina[i].name, nomina[j].name)==0){
                    if(stricmp(nomina[i].lastName, nomina[j].lastName)==1){
                        auxEmp=nomina[i];
                        nomina[i]=nomina[j];
                        nomina[j]=auxEmp;
                    }
                }
            }
        }
    }

}

void hardCodearEmpleados(eEmployee nomina[], int tam){

    eEmployee empleados[]={
        {1001,"Juan","Perez",25000,1,0},
        {1002,"Maria","Luces",30000,2,0},
        {1003,"Lucas","Messi",15000,3,0},
        {1004,"Belen","Curcio",20000,1,0},
        {1005,"Mario","Beliz",90000,2,0},
        {1006,"Juana","De arco",20000,3,0},
        {1007,"Daniel","Yo",9000,1,0},
        {1008,"Kevin","Clas",70000,2,0},
        {1009,"Claudia","Ella",120000,3,0}
            };

    for(int i=0 ; i<tam ; i++){
        nomina[i]=empleados[i];
    }

}

