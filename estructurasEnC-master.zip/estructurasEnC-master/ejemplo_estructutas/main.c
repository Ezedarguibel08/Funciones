    #include <stdio.h>
    #include <stdlib.h>

    typedef struct {
        int legajo;
        char nombre[50];
        int nota1;
        int nota2;
        float promedio;
    } eAlumno;


    int main(){

        ordenarPorPromedio(alumno listado[5]){

        }

        buscarLugarLibre(alumno listado[5]){

        }

        cargarAlumno(alumno listado[5], alumno){


        }

    alumno pedirAlumno(void)
    {

    }

    mostrarAlumnos()
    {

    }

    borrarAlumno()
    {

    }
}
